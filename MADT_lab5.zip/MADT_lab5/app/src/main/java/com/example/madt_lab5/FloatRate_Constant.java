package com.example.madt_lab5;


public class FloatRate_Constant {
;
    public static final String FloatRate_Url = "http://www.floatrates.com/daily/usd.xml";
}
